# -*- coding; utf-8 -*- 
'''
======================
author:shirui
time:2020/7/3
======================
'''

import operator
res = operater.exist("登录去！", "unlogin")
print(res
    )